"""
تعريف نماذج (Forms) لتسهيل التعامل مع بيانات المستخدمين والمنتجات.
تم التحديث لاستخدام CustomUser.
"""

from django import forms
# لم نعد نستورد User من django.contrib.auth.models
from .models import Product, CustomUser # تم استيراد CustomUser

# نموذج تسجيل مستخدم جديد
class RegisterForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput, label="كلمة المرور")
    password2 = forms.CharField(widget=forms.PasswordInput, label="تأكيد كلمة المرور")
    email = forms.EmailField(label="البريد الإلكتروني")

    class Meta:
        model = CustomUser # تم التغيير إلى CustomUser
        fields = ['username', 'email', 'password']
        labels = {
            'username': 'اسم المستخدم',
            'email': 'البريد الإلكتروني',
        }

    def clean_password2(self):
        password = self.cleaned_data.get('password')
        password2 = self.cleaned_data.get('password2')
        if password and password2 and password != password2:
            raise forms.ValidationError("كلمتا المرور غير متطابقتين.")
        return password2

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password"])
        # عند التسجيل، اجعل المستخدم غير نشط وبانتظار الموافقة
        user.is_active = False
        user.is_approved = False
        user.is_admin = False # تأكد أنه ليس أدمن عند التسجيل
        if commit:
            user.save()
        return user

# نموذج إضافة/تعديل منتج (للمدير)
class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'description', 'quantity']
        labels = {
            'name': 'اسم المنتج',
            'description': 'الوصف',
            'quantity': 'الكمية المتاحة',
        }
