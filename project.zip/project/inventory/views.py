"""
منطق العمليات والوظائف (Views) لتطبيق المخزون.
تمت إعادة هيكلة لوحة تحكم المدير ودوال إدارة المنتجات والمستخدمين والطلبات
لاستخدام دوال عرض منفصلة ونماذج Django Forms، وتم التحديث لاستخدام CustomUser.
"""

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth import authenticate, login, logout, get_user_model # تم استيراد get_user_model
from django.core.mail import send_mail
from django.conf import settings
from django.db.models import Sum
from datetime import datetime, timedelta
import calendar
from django.contrib import messages

# استيراد CustomUser بدلاً من User و UserProfile
from .models import Product, Order, ConsumptionRecord, CustomUser
from .forms import RegisterForm, ProductForm

# دالة مساعدة للتحقق مما إذا كان المستخدم أدمن
def is_admin(user):
    return user.is_admin # تم التغيير إلى is_admin مباشرة من CustomUser

# 👤 عرض صفحة تسجيل الدخول
def login_view(request):
    if request.user.is_authenticated:
        if request.user.is_admin: # تم التغيير إلى is_admin
            return redirect('admin_dashboard')
        return redirect('dashboard')

    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            if user.is_admin: # تم التغيير إلى is_admin
                login(request, user)
                return redirect('admin_dashboard')
            # إذا كان مستخدم عادي، تحقق من الموافقة
            if user.is_approved: # تم التغيير إلى is_approved مباشرة من CustomUser
                login(request, user)
                return redirect('dashboard')
            else:
                messages.error(request, 'حسابك بانتظار موافقة المدير.')
        else:
            messages.error(request, 'اسم المستخدم أو كلمة المرور غير صحيحة.')
    return render(request, 'login.html')

# 👤 عرض صفحة تسجيل مستخدم جديد
def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')

    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save() # النموذج سيتولى is_active و is_approved
            messages.success(request, 'تم إرسال طلب التسجيل بنجاح. حسابك بانتظار موافقة المدير.')
            return redirect('login')
        else:
            messages.error(request, 'حدث خطأ أثناء التسجيل. يرجى التحقق من البيانات المدخلة.')
    else:
        form = RegisterForm()
    return render(request, 'register.html', {'form': form})

# 👤 تسجيل الخروج
@login_required
def logout_view(request):
    logout(request)
    return redirect('login')

# 🛒 لوحة تحكم المستخدم
@login_required
# التحقق من is_approved مباشرة من request.user
@user_passes_test(lambda u: u.is_approved if not u.is_admin else True, login_url='login')
def dashboard(request):
    products = Product.objects.all()
    orders = Order.objects.filter(user=request.user).order_by('-created_at')

    thirty_days_ago = datetime.now() - timedelta(days=30)
    top_consumed_products = ConsumptionRecord.objects.filter(
        user=request.user,
        consumed_at__gte=thirty_days_ago
    ).values('product__name').annotate(total_consumed=Sum('quantity_consumed')).order_by('-total_consumed')[:5]

    low_stock_products = Product.objects.filter(quantity__lte=5)

    current_month_start = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    next_month_start = (current_month_start + timedelta(days=32)).replace(day=1)
    
    monthly_consumption = ConsumptionRecord.objects.filter(
        user=request.user,
        consumed_at__gte=current_month_start,
        consumed_at__lt=next_month_start
    ).values('product__name').annotate(total_consumed=Sum('quantity_consumed'))

    context = {
        'products': products,
        'orders': orders,
        'top_consumed_products': top_consumed_products,
        'low_stock_products': low_stock_products,
        'monthly_consumption': monthly_consumption,
        'current_month': datetime.now().strftime('%B %Y')
    }
    return render(request, 'dashboard.html', context)

# 🛒 تقديم طلب جديد
@login_required
@user_passes_test(lambda u: u.is_approved if not u.is_admin else True, login_url='login')
def place_order(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        try:
            qty = int(request.POST['quantity'])
            if qty > 0 and qty <= product.quantity:
                Order.objects.create(user=request.user, product=product, quantity=qty, status='Pending')
                messages.success(request, 'تم تقديم طلبك بنجاح.')
                return redirect('dashboard')
            else:
                messages.error(request, 'الكمية المطلوبة غير صالحة أو أكبر من المتاح.')
        except ValueError:
            messages.error(request, 'الكمية يجب أن تكون رقمًا صحيحًا.')
    return render(request, 'place_order.html', {'product': product})

# 🛠️ لوحة تحكم المدير (للعرض فقط)
@login_required
@user_passes_test(is_admin, login_url='login')
def admin_dashboard(request):
    # جلب المستخدمين الذين ليسوا أدمن وغير موافق عليهم
    users_to_approve = CustomUser.objects.filter(is_admin=False, is_approved=False)
    orders = Order.objects.all().order_by('-created_at')
    products = Product.objects.all().order_by('name')
    
    current_month_start = datetime.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    next_month_start = (current_month_start + timedelta(days=32)).replace(day=1)
    
    admin_monthly_consumption = ConsumptionRecord.objects.filter(
        consumed_at__gte=current_month_start,
        consumed_at__lt=next_month_start
    ).values('product__name', 'user__username').annotate(total_consumed=Sum('quantity_consumed')).order_by('-total_consumed')

    context = {
        'pending_users': users_to_approve, # تم تغيير الاسم ليكون أكثر وضوحًا
        'orders': orders,
        'products': products,
        'admin_monthly_consumption': admin_monthly_consumption,
        'current_month': datetime.now().strftime('%B %Y')
    }
    return render(request, 'admin_dashboard.html', context)

# ➕ إضافة منتج جديد (للمدير)
@login_required
@user_passes_test(is_admin, login_url='login')
def product_add(request):
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'تمت إضافة المنتج بنجاح.')
            return redirect('admin_dashboard')
        else:
            messages.error(request, 'حدث خطأ أثناء إضافة المنتج. يرجى التحقق من البيانات.')
    else:
        form = ProductForm()
    return render(request, 'add_product.html', {'form': form})

# ✏️ تعديل منتج موجود (للمدير)
@login_required
@user_passes_test(is_admin, login_url='login')
def product_edit(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        form = ProductForm(request.POST, instance=product)
        if form.is_valid():
            form.save()
            messages.success(request, 'تم تعديل المنتج بنجاح.')
            return redirect('admin_dashboard')
        else:
            messages.error(request, 'حدث خطأ أثناء تعديل المنتج. يرجى التحقق من البيانات.')
    else:
        form = ProductForm(instance=product)
    return render(request, 'edit_product.html', {'form': form, 'product': product})

# 🗑️ حذف منتج (للمدير)
@login_required
@user_passes_test(is_admin, login_url='login')
def product_delete(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        product.delete()
        messages.success(request, 'تم حذف المنتج بنجاح.')
        return redirect('admin_dashboard')
    return render(request, 'delete_product_confirm.html', {'product': product})

# ✅ موافقة المدير على طلب تسجيل مستخدم
@login_required
@user_passes_test(is_admin, login_url='login')
def user_approve(request, user_id):
    user = get_object_or_404(CustomUser, id=user_id) # تم التغيير إلى CustomUser
    user.is_approved = True
    user.is_active = True
    user.save()

    send_mail(
        'تمت الموافقة على حسابك ✅',
        f"مرحباً {user.username},\n\nتهانينا، تمت الموافقة على حسابك في نظام إدارة المخزون. يمكنك الآن تسجيل الدخول والبدء في استخدام النظام.\n\nمع خالص التقدير,\nفريق إدارة المخزون",
        settings.EMAIL_HOST_USER,
        [user.email],
        fail_silently=False,
    )
    messages.success(request, f'تمت الموافقة على المستخدم {user.username}.')
    return redirect('admin_dashboard')

# ❌ رفض المدير لطلب تسجيل مستخدم
@login_required
@user_passes_test(is_admin, login_url='login')
def user_reject(request, user_id):
    user = get_object_or_404(CustomUser, id=user_id) # تم التغيير إلى CustomUser
    username = user.username
    user_email = user.email
    user.delete() # حذف المستخدم بالكامل

    send_mail(
        'طلب حسابك مرفوض ❌',
        f"مرحباً {username},\n\nنأسف لإبلاغك أن طلب حسابك في نظام إدارة المخزون قد تم رفضه.\n\nمع خالص التقدير,\nفريق إدارة المخزون",
        settings.EMAIL_HOST_USER,
        [user_email],
        fail_silently=False,
    )
    messages.info(request, f'تم رفض حساب المستخدم {username} وحذفه.')
    return redirect('admin_dashboard')

# ✅ موافقة المدير على الطلب
@login_required
@user_passes_test(is_admin, login_url='login')
def order_approve(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    if order.status == 'Pending':
        order.status = 'Approved'
        order.approved_at = datetime.now()
        order.save()

        ConsumptionRecord.objects.create(
            user=order.user,
            product=order.product,
            quantity_consumed=order.quantity
        )

        send_mail(
            'طلبك تمت الموافقة عليه ✅',
            f"مرحباً {order.user.username},\n\nتمت الموافقة على طلبك لمنتج '{order.product.name}' بكمية {order.quantity}.\n\nيمكنك الآن استلام طلبك من المخزن. يرجى التنسيق مع إدارة المخزن لتحديد موعد الاستلام.\n\nمع خالص التقدير,\nفريق إدارة المخزون",
            settings.EMAIL_HOST_USER,
            [order.user.email],
            fail_silently=False,
        )
        messages.success(request, f'تمت الموافقة على الطلب #{order.id}.')
    else:
        messages.warning(request, f'لا يمكن الموافقة على الطلب #{order.id} لأنه ليس في حالة "معلق".')
    return redirect('admin_dashboard')

# ❌ رفض المدير للطلب
@login_required
@user_passes_test(is_admin, login_url='login')
def order_reject(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    if order.status == 'Pending':
        order.status = 'Rejected'
        order.save()

        send_mail(
            'طلبك مرفوض ❌',
            f"مرحباً {order.user.username},\n\nنأسف لإبلاغك أن طلبك لمنتج '{order.product.name}' بكمية {order.quantity} قد تم رفضه.\n\nلأي استفسارات، يرجى التواصل مع إدارة المخزون.\n\nمع خالص التقدير,\nفريق إدارة المخزون",
            settings.EMAIL_HOST_USER,
            [order.user.email],
            fail_silently=False,
        )
        messages.info(request, f'تم رفض الطلب #{order.id}.')
    else:
        messages.warning(request, f'لا يمكن رفض الطلب #{order.id} لأنه ليس في حالة "معلق".')
    return redirect('admin_dashboard')
