"""
روابط (URLs) تطبيق المخزون.
تم تصحيح اسم دالة لوحة تحكم المستخدم من 'user_dashboard' إلى 'dashboard'.
"""

from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login_view, name='login'), # صفحة تسجيل الدخول
    path('register/', views.register_view, name='register'), # صفحة تسجيل مستخدم جديد
    path('logout/', views.logout_view, name='logout'), # تسجيل الخروج

    # روابط لوحة تحكم المستخدم
    path('dashboard/', views.dashboard, name='dashboard'), # لوحة تحكم المستخدم (تم التأكد من الاسم)
    path('place_order/<int:product_id>/', views.place_order, name='place_order'), # تقديم طلب لمنتج

    # روابط لوحة تحكم المدير (تم تقسيمها)
    path('admin_dashboard/', views.admin_dashboard, name='admin_dashboard'), # لوحة تحكم المدير الرئيسية (للعرض)
    
    # إدارة المستخدمين من قبل المدير
    path('admin/users/<int:user_id>/approve/', views.user_approve, name='user_approve'), # موافقة على مستخدم
    path('admin/users/<int:user_id>/reject/', views.user_reject, name='user_reject'), # رفض مستخدم

    # إدارة المنتجات من قبل المدير
    path('admin/products/add/', views.product_add, name='product_add'), # إضافة منتج
    path('admin/products/edit/<int:product_id>/', views.product_edit, name='product_edit'), # تعديل منتج
    path('admin/products/delete/<int:product_id>/', views.product_delete, name='product_delete'), # حذف منتج

    # إدارة الطلبات من قبل المدير
    path('admin/orders/<int:order_id>/approve/', views.order_approve, name='order_approve'), # موافقة على طلب
    path('admin/orders/<int:order_id>/reject/', views.order_reject, name='order_reject'), # رفض طلب
]