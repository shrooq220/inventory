"""
تسجيل النماذج في لوحة تحكم الأدمن لتمكين الإدارة من خلال الواجهة الإدارية.
تم التحديث لاستخدام CustomUser.
"""

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
# لم نعد نستورد User من django.contrib.auth.models
from .models import Product, Order, CustomUser, ConsumptionRecord # تم استيراد CustomUser

# لا نحتاج UserProfileInline بعد الآن لأن is_approved أصبح جزءًا من CustomUser
# class UserProfileInline(admin.StackedInline):
#     model = UserProfile
#     can_delete = False
#     verbose_name_plural = 'ملف تعريف المستخدم'

# تخصيص لوحة تحكم CustomUser
class CustomUserAdmin(BaseUserAdmin):
    # inlines = (UserProfileInline,) # تم إزالة هذا
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_staff', 'is_approved') # is_approved موجود مباشرة
    list_filter = ('is_staff', 'is_superuser', 'is_active', 'groups', 'is_approved') # is_approved موجود مباشرة
    fieldsets = BaseUserAdmin.fieldsets + (
        (('Custom Fields'), {'fields': ('is_admin', 'is_approved',)}), # إضافة حقولنا المخصصة
    )

# إلغاء تسجيل User الأصلي (إذا كان مسجلاً) وإعادة تسجيل CustomUser
# تأكد من أن User لم يتم تسجيله بالفعل في مكان آخر
try:
    admin.site.unregister(CustomUser) # حاول إلغاء التسجيل إذا كان مسجلاً بالفعل
except admin.sites.NotRegistered:
    pass # لا تفعل شيئًا إذا لم يكن مسجلاً

admin.site.register(CustomUser, CustomUserAdmin) # تسجيل CustomUser

# تسجيل النماذج الأخرى
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'quantity', 'created_at')
    search_fields = ('name', 'description')
    list_filter = ('created_at',)

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'product', 'quantity', 'status', 'created_at', 'approved_at')
    list_filter = ('status', 'created_at', 'user')
    search_fields = ('user__username', 'product__name')
    raw_id_fields = ('user', 'product')

@admin.register(ConsumptionRecord)
class ConsumptionRecordAdmin(admin.ModelAdmin):
    list_display = ('user', 'product', 'quantity_consumed', 'consumed_at')
    list_filter = ('consumed_at', 'user', 'product')
    search_fields = ('user__username', 'product__name')
