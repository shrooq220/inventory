# project/urls.py
from django.contrib import admin
from django.urls import path, include, reverse_lazy # استيراد reverse_lazy
from django.views.generic import RedirectView # استيراد RedirectView
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls), # لوحة تحكم Django الإدارية
    # تم تغيير إعادة التوجيه لتوجه إلى اسم الـ URL الصحيح لصفحة تسجيل الدخول في تطبيق inventory
    path('', RedirectView.as_view(url=reverse_lazy('login'), permanent=False)), 
    path('inventory/', include('inventory.urls')), # هذا السطر هو الأهم، تأكد من وجوده بالضبط هكذا
]

# لخدمة ملفات الميديا والملفات الثابتة في وضع التطوير
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    # هذا السطر لخدمة ملفات static التي يتم جمعها بواسطة collectstatic (اختياري في التطوير)
    # يمكنك إزالته إذا كنت تعتمد فقط على STATICFILES_DIRS
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT or settings.STATICFILES_DIRS[0])

