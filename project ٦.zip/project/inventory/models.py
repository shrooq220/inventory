# inventory/models.py
from django.db import models
from django.contrib.auth.models import AbstractUser

# نموذج المستخدم المخصص
class CustomUser(AbstractUser):
    # حقول إضافية للمستخدمين
    is_admin = models.BooleanField(default=False)
    is_approved = models.BooleanField(default=False)

    # خيارات الأقسام
    DEPARTMENT_CHOICES = [
        ('physical_therapy', 'قسم العلاج الطبيعي'),
        ('occupational_therapy', 'قسم العلاج الوظيفي'),
        ('respiratory_therapy', 'قسم العلاج التنفسي'),
        ('speech_hearing', 'قسم أمراض التخاطب والسمع'),
        ('prosthetics_orthotics', 'قسم الأطراف الصناعية والأجهزة التعويضية'),
    ]
    department = models.CharField(
        max_length=50,
        choices=DEPARTMENT_CHOICES,
        blank=True, # السماح بأن يكون فارغاً (غير إلزامي عند التسجيل إذا لم يتم اختياره)
        null=True,   # السماح بقيم NULL في قاعدة البيانات
        verbose_name="القسم"
    )

    class Meta:
        # إضافة الصلاحيات المخصصة هنا
        permissions = [
            ("can_manage_products", "Can add, edit, and delete products"),
            ("can_approve_users", "Can approve or reject new user registrations"),
            ("can_manage_orders", "Can approve or reject product orders"),
            # يمكنك إضافة المزيد من الصلاحيات هنا حسب الحاجة
        ]
        verbose_name = "مستخدم مخصص"
        verbose_name_plural = "المستخدمون المخصصون"

    def __str__(self):
        return self.username

# نموذج المنتج
class Product(models.Model):
    CATEGORY_CHOICES = [
        ('medical_tools', 'أدوات طبية'),
        ('office_supplies', 'مستلزمات مكتبية'),
        ('cleaning_supplies', 'أدوات تنظيف'),
        # يمكنك إضافة المزيد من الفئات هنا
    ]
    name = models.CharField(max_length=255, verbose_name="اسم المنتج")
    description = models.TextField(blank=True, verbose_name="الوصف")
    quantity = models.PositiveIntegerField(default=0, verbose_name="الكمية")
    category = models.CharField(max_length=50, choices=CATEGORY_CHOICES, verbose_name="الفئة")
    image = models.ImageField(upload_to='product_images/', blank=True, null=True, verbose_name="صورة المنتج")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ الإضافة")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="تاريخ التحديث")

    class Meta:
        verbose_name = "منتج"
        verbose_name_plural = "المنتجات"
        ordering = ['name']

    def __str__(self):
        return self.name

# نموذج سلة التسوق (Cart)
class Cart(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, verbose_name="المستخدم")
    product = models.ForeignKey(Product, on_delete=models.CASCADE, verbose_name="المنتج")
    quantity = models.PositiveIntegerField(default=1, verbose_name="الكمية")
    added_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ الإضافة للسلة")

    class Meta:
        verbose_name = "سلة تسوق"
        verbose_name_plural = "سلات التسوق"
        unique_together = ('user', 'product') # لضمان وجود منتج واحد فقط من نوع معين في سلة المستخدم
        ordering = ['added_at']

    def __str__(self):
        return f"سلة {self.user.username} - {self.product.name} ({self.quantity})"


# نموذج الطلب
class Order(models.Model):
    STATUS_CHOICES = [
        ('Pending', 'قيد الانتظار'),
        ('Approved', 'تمت الموافقة'),
        ('Rejected', 'مرفوض'),
    ]
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, verbose_name="المستخدم")
    product = models.ForeignKey(Product, on_delete=models.CASCADE, verbose_name="المنتج")
    quantity = models.PositiveIntegerField(verbose_name="الكمية المطلوبة")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='Pending', verbose_name="الحالة")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ الطلب")
    approved_at = models.DateTimeField(null=True, blank=True, verbose_name="تاريخ الموافقة")

    class Meta:
        verbose_name = "طلب"
        verbose_name_plural = "الطلبات"
        ordering = ['-created_at']

    def __str__(self):
        return f"طلب #{self.id} - {self.product.name} ({self.quantity}) بواسطة {self.user.username}"

# نموذج سجل الاستهلاك (لتقارير الاستهلاك الفردية)
class ConsumptionRecord(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, verbose_name="المستخدم")
    product = models.ForeignKey(Product, on_delete=models.CASCADE, verbose_name="المنتج")
    quantity = models.PositiveIntegerField(verbose_name="الكمية المستهلكة")
    consumed_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ الاستهلاك")

    class Meta:
        verbose_name = "سجل استهلاك"
        verbose_name_plural = "سجلات الاستهلاك"
        ordering = ['-consumed_at']

    def __str__(self):
        return f"{self.user.username} استهلك {self.quantity} من {self.product.name}"

# نموذج التقرير (لتقارير الاستهلاك الشهرية المجمعة)
class Report(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, verbose_name="المستخدم")
    month = models.CharField(max_length=7, verbose_name="الشهر")  # Format: YYYY-MM
    product = models.ForeignKey(Product, on_delete=models.CASCADE, verbose_name="المنتج")
    consumed = models.PositiveIntegerField(default=0, verbose_name="الكمية المستهلكة")
    remaining = models.IntegerField(verbose_name="الكمية المتبقية")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="تاريخ التقرير")

    class Meta:
        verbose_name = "تقرير"
        verbose_name_plural = "التقارير"
        unique_together = ('user', 'month', 'product') # ضمان عدم تكرار التقرير لنفس المستخدم والمنتج في نفس الشهر
        ordering = ['-month', 'user__username', 'product__name']

    def __str__(self):
        return f"تقرير {self.month} لـ {self.product.name} بواسطة {self.user.username}"