# inventory/forms.py
from django import forms
from .models import CustomUser, Product

class RegisterForm(forms.Form):
    username = forms.CharField(max_length=150, label="اسم المستخدم")
    email = forms.EmailField(label="البريد الإلكتروني")
    # إضافة حقل القسم
    department = forms.ChoiceField(
        choices=CustomUser.DEPARTMENT_CHOICES,
        label="القسم",
        required=False, # اجعله غير إلزامي إذا كان المستخدم لا ينتمي لقسم معين
        widget=forms.Select(attrs={'class': 'form-control'}) # إضافة فئة Bootstrap
    )
    password = forms.CharField(widget=forms.PasswordInput, label="كلمة المرور")
    password2 = forms.CharField(widget=forms.PasswordInput, label="تأكيد كلمة المرور")

    def clean_password2(self):
        cd = self.cleaned_data
        if cd['password'] != cd['password2']:
            raise forms.ValidationError('كلمتا المرور غير متطابقتين.')
        return cd['password2']

    def clean_email(self):
        email = self.cleaned_data['email']
        if CustomUser.objects.filter(email=email).exists():
            raise forms.ValidationError("هذا البريد الإلكتروني مسجل بالفعل.")
        return email

    def clean_username(self):
        username = self.cleaned_data['username']
        if CustomUser.objects.filter(username=username).exists():
            raise forms.ValidationError("اسم المستخدم هذا مأخوذ بالفعل.")
        return username

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'description', 'quantity', 'category', 'image']
