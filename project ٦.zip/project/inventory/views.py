from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test, permission_required
from django.contrib.auth import authenticate, login, logout, get_user_model, update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm, AuthenticationForm # تم إضافة AuthenticationForm
from django.core.mail import send_mail
from django.conf import settings
from django.db.models import Sum
from datetime import datetime, timedelta
import calendar
from django.contrib import messages

# استيراد CustomUser والنماذج الأخرى
from .models import Product, Order, ConsumptionRecord, CustomUser, Cart, Report
from .forms import RegisterForm, ProductForm

# دالة مساعدة للتحقق مما إذا كان المستخدم أدمن
def is_admin(user):
    """يتحقق مما إذا كان المستخدم لديه صلاحيات المدير."""
    return user.is_admin

# دالة مساعدة للتحقق مما إذا كان المستخدم لديه صلاحيات مدير محدودة
def has_limited_admin_permissions(user):
    """
    يتحقق مما إذا كان المستخدم هو مدير ولديه إما صلاحية إدارة المنتجات
    أو صلاحية إدارة الطلبات.
    """
    return user.is_admin and (
        user.has_perm('inventory.can_manage_products') or
        user.has_perm('inventory.can_manage_orders')
    )

# 👤 عرض صفحة تسجيل الدخول
def login_view(request):
    """
    يعالج تسجيل دخول المستخدمين (المديرين والمستخدمين العاديين).
    يوجه المستخدمين بناءً على دورهم وحالة الموافقة.
    """
    if request.user.is_authenticated:
        if request.user.is_superuser: # المشرف العام يذهب إلى لوحة تحكم المدير الكاملة
            return redirect('inventory:admin_dashboard')
        elif request.user.is_admin and has_limited_admin_permissions(request.user):
            # المدير الجزئي يذهب إلى لوحة تحكم المدير المحدودة
            return redirect('inventory:limited_admin_dashboard')
        elif request.user.is_approved:
            # المستخدم العادي الموافق عليه يذهب إلى لوحة تحكم المستخدم
            return redirect('inventory:user_dashboard')
        else:
            # المستخدم العادي غير الموافق عليه يظل في صفحة تسجيل الدخول مع رسالة
            messages.info(request, 'حسابك بانتظار موافقة المدير.')
            return render(request, 'login.html')

    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST) # إنشاء النموذج مع بيانات POST
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user is not None:
                if user.is_superuser:
                    login(request, user)
                    messages.success(request, f'مرحباً بك يا مدير {user.username}!')
                    return redirect('inventory:admin_dashboard')
                elif user.is_admin and has_limited_admin_permissions(user):
                    login(request, user)
                    messages.success(request, f'مرحباً بك يا مدير {user.username}!')
                    return redirect('inventory:limited_admin_dashboard')
                elif user.is_approved:
                    login(request, user)
                    messages.success(request, f'مرحباً بك {user.username}!')
                    return redirect('inventory:user_dashboard')
                else:
                    messages.error(request, 'حسابك بانتظار موافقة المدير.')
                    logout(request) # تسجيل الخروج إذا لم تتم الموافقة
            else:
                messages.error(request, 'اسم المستخدم أو كلمة المرور غير صحيحة.')
        else:
            # إذا لم يكن النموذج صالحًا، ستظهر الأخطاء في القالب
            messages.error(request, 'الرجاء إدخال بيانات صحيحة لتسجيل الدخول.')
    else:
        form = AuthenticationForm() # إنشاء نموذج فارغ لطلب GET

    return render(request, 'login.html', {'form': form}) # تمرير النموذج إلى القالب

# 👤 عرض صفحة تسجيل مستخدم جديد
def register_view(request):
    """
    يعالج طلبات تسجيل المستخدمين الجدد.
    ينشئ حساب CustomUser ويضع is_approved و is_active على False حتى تتم الموافقة.
    """
    if request.user.is_authenticated:
        return redirect('inventory:user_dashboard')

    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            # إنشاء المستخدم مباشرة وتعيين is_approved=False و is_active=False
            user = CustomUser.objects.create_user(
                username=form.cleaned_data['username'],
                email=form.cleaned_data['email'],
                password=form.cleaned_data['password'],
                department=form.cleaned_data.get('department'), # حفظ القسم هنا
                is_approved=False, # بانتظار موافقة المدير
                is_active=False # غير نشط حتى تتم الموافقة
            )
            messages.success(request, 'تم إرسال طلب التسجيل بنجاح. حسابك بانتظار موافقة المدير.')
            return redirect('inventory:login')
        else:
            # رسائل الخطأ من النموذج ستظهر تلقائياً في القالب
            messages.error(request, 'حدث خطأ أثناء التسجيل. يرجى التحقق من البيانات المدخلة.')
    else:
        form = RegisterForm()
    return render(request, 'register.html', {'form': form})

# 👤 تسجيل الخروج
@login_required
def logout_view(request):
    """يسجل خروج المستخدم الحالي ويعيد توجيهه إلى صفحة تسجيل الدخول."""
    logout(request)
    messages.info(request, 'تم تسجيل الخروج بنجاح.')
    return redirect('inventory:login')

# 🛒 لوحة تحكم المستخدم
@login_required
# التحقق من is_approved مباشرة من request.user لغير المديرين
@user_passes_test(lambda u: u.is_approved if not u.is_admin else True, login_url='inventory:login')
def user_dashboard(request):
    """
    يعرض لوحة تحكم المستخدم مع المنتجات المتاحة،
    ويعالج إضافة المنتجات إلى السلة.
    """
    # إضافة منطق تصفية المنتجات حسب الفئة والبحث
    category = request.GET.get('category', 'all')
    query = request.GET.get('q', '')
    products = Product.objects.all()
    if category != 'all':
        products = products.filter(category=category)
    if query:
        products = products.filter(name__icontains=query)
    
    if request.method == 'POST':
        product_id = request.POST['product_id']
        quantity = int(request.POST['quantity'])
        product = get_object_or_404(Product, id=product_id)
        
        if quantity > 0 and quantity <= product.quantity:
            # إضافة المنتج إلى سلة التسوق (Cart) أو تحديث الكمية إذا كان موجودًا
            cart_item, created = Cart.objects.get_or_create(
                user=request.user, 
                product=product,
                defaults={'quantity': quantity}
            )
            if not created:
                cart_item.quantity += quantity
                cart_item.save()
            messages.success(request, 'تمت إضافة المنتج إلى السلة.')
        else:
            messages.error(request, 'الكمية غير متوفرة أو غير صالحة.')
        return redirect('inventory:user_dashboard')

    return render(request, 'inventory/user_dashboard.html', {'products': products, 'category': category, 'query': query})

# 🛒 عرض صفحة السلة
@login_required
def cart_view(request):
    """
    يعرض سلة التسوق للمستخدم، ويتيح تحديث الكميات، إزالة المنتجات، وتأكيد الطلب.
    """
    if request.user.is_admin:
        messages.warning(request, 'لا يمكنك الوصول إلى سلة التسوق كمدير.')
        if request.user.is_superuser or request.user.has_perm('inventory.can_approve_users'):
            return redirect('inventory:admin_dashboard')
        elif request.user.has_perm('inventory.can_manage_products') or request.user.has_perm('inventory.can_manage_orders'):
            return redirect('inventory:limited_admin_dashboard')
        else:
            logout(request)
            messages.error(request, 'ليس لديك صلاحيات كافية للوصول إلى هذه الصفحة.')
            return redirect('inventory:login')

    cart_items = Cart.objects.filter(user=request.user)
    
    if request.method == 'POST':
        action = request.POST.get('action')
        
        if action == 'update_cart':
            for item in cart_items:
                quantity_key = f'quantity_{item.id}'
                if quantity_key in request.POST:
                    new_quantity = int(request.POST[quantity_key])
                    if new_quantity > 0 and new_quantity <= item.product.quantity:
                        item.quantity = new_quantity
                        item.save()
                    elif new_quantity <= 0: # إذا كانت الكمية 0 أو أقل، احذف العنصر من السلة
                        item.delete()
                    else:
                        messages.error(request, f'الكمية المطلوبة لـ {item.product.name} غير متوفرة ({item.product.quantity} متاح).')
            messages.success(request, 'تم تحديث السلة.')
        
        elif action == 'confirm_order':
            if not cart_items.exists(): # منع تأكيد طلب سلة فارغة
                messages.error(request, 'لا يمكن تأكيد طلب من سلة فارغة.')
                return redirect('inventory:cart_view')

            for item in cart_items:
                # التحقق مرة أخرى من الكمية المتاحة قبل إنشاء الطلب
                product = item.product
                if item.quantity > product.quantity:
                    messages.error(request, f'الكمية المطلوبة لـ {product.name} ({item.quantity}) أكبر من المتاح ({product.quantity}). يرجى تعديل السلة.')
                    return redirect('inventory:cart_view')

                # إنشاء طلب جديد لكل عنصر في السلة وتعيين الحالة إلى 'Pending'
                Order.objects.create(user=request.user, product=product, quantity=item.quantity, status='Pending')
                # لا تقم بخصم الكمية من هنا، سيتم خصمها عند الموافقة عليها من قبل المدير
                item.delete() # حذف العنصر من السلة بعد تأكيد الطلب
            messages.success(request, 'تم تأكيد الطلب وإرساله إلى الإدارة. حالته قيد الانتظار.')
            return redirect('inventory:order_tracking_view')
        
        elif action and action.startswith('remove_item_'): # معالجة زر الإزالة الفردي
            item_id = action.split('_')[2]
            item_to_remove = get_object_or_404(Cart, id=item_id, user=request.user)
            item_to_remove.delete()
            messages.success(request, f'تمت إزالة {item_to_remove.product.name} من السلة.')
            return redirect('inventory:cart_view')
        
        return redirect('inventory:cart_view')
    
    return render(request, 'cart.html', {'cart_items': cart_items})

# 🛒 عرض صفحة تتبع الطلبات
@login_required
def order_tracking_view(request):
    """يعرض الطلبات السابقة للمستخدم وحالتها."""
    # إذا كان المستخدم مديرًا، أعد توجيهه إلى لوحة تحكم المدير
    if request.user.is_admin:
        messages.warning(request, 'لا يمكنك الوصول إلى صفحة تتبع الطلبات كمدير.')
        # يمكن توجيههم إلى لوحة التحكم الكاملة أو المحدودة حسب الصلاحيات
        if request.user.is_superuser or request.user.has_perm('inventory.can_approve_users'):
            return redirect('inventory:admin_dashboard')
        elif request.user.has_perm('inventory.can_manage_products') or request.user.has_perm('inventory.can_manage_orders'):
            return redirect('inventory:limited_admin_dashboard')
        else: # إذا كان مديرًا ولكن ليس لديه صلاحيات محددة، أعده إلى صفحة تسجيل الدخول
            logout(request)
            messages.error(request, 'ليس لديك صلاحيات كافية للوصول إلى هذه الصفحة.')
            return redirect('inventory:login')
    
    # تأكد أن المستخدم العادي موافق عليه
    if not request.user.is_approved:
        messages.error(request, 'حسابك بانتظار موافقة المدير.')
        return redirect('inventory:login') # أو أي صفحة مناسبة

    orders = Order.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'order_tracking.html', {'orders': orders})

# 🛠️ لوحة تحكم المدير الكاملة
@login_required
@user_passes_test(is_admin, login_url='inventory:login') # يمكن للمدير الوصول إلى لوحة التحكم
def admin_dashboard(request):
    """
    يعرض لوحة تحكم المدير مع طلبات تسجيل المستخدمين المعلقة،
    إدارة المنتجات، إدارة الطلبات، وتقارير الاستهلاك.
    ويعالج جميع إجراءات POST المتعلقة بهذه الأقسام.
    """
    # فلترة المستخدمين الذين لم تتم الموافقة عليهم بعد
    pending_users = CustomUser.objects.filter(is_admin=False, is_approved=False)
    
    products = Product.objects.all()
    query = request.GET.get('q', '')
    if query:
        products = products.filter(name__icontains=query)

    low_stock_products = Product.objects.filter(quantity__lte=15).order_by('quantity')
    
    orders = Order.objects.all().order_by('-created_at')
    reports = Report.objects.all().order_by('-created_at')
    
    # حساب إجمالي الاستهلاك لكل منتج ولكل قسم (للوحة تحكم المدير)
    department_consumption_data = ConsumptionRecord.objects.values(
        'product__name',
        'user__department'
    ).annotate(
        total_consumed=Sum('quantity')
    ).order_by('user__department', 'product__name')

    # تحويل الاختصارات إلى أسماء كاملة للقسم
    for item in department_consumption_data:
        for choice_value, choice_label in CustomUser.DEPARTMENT_CHOICES:
            if choice_value == item['user__department']:
                item['department_display'] = choice_label
                break
        else:
            item['department_display'] = "غير محدد"

    return render(request, 'inventory/admin_dashboard.html', {
        'users': CustomUser.objects.filter(is_admin=False),
        'pending_users': pending_users,
        'products': products,
        'low_stock_products_admin': low_stock_products,
        'orders': orders,
        'reports': reports,
        'admin_monthly_consumption': department_consumption_data,
        'current_month': datetime.now().strftime('%B %Y')
    })

# 🛠️ لوحة تحكم المدير المحدودة (للمستخدمين ذوي الصلاحيات الجزئية)
@login_required
@user_passes_test(has_limited_admin_permissions, login_url='inventory:login')
def limited_admin_dashboard(request):
    """
    يعرض لوحة تحكم للمديرين ذوي الصلاحيات المحدودة (إدارة المنتجات والطلبات).
    """
    products = Product.objects.all()
    query = request.GET.get('q', '')
    if query:
        products = products.filter(name__icontains=query)

    low_stock_products = Product.objects.filter(quantity__lte=15).order_by('quantity')
    
    orders = Order.objects.all().order_by('-created_at')
    
    # حساب إجمالي الاستهلاك لكل منتج ولكل قسم (للوحة تحكم المدير المحدودة)
    department_consumption_data = ConsumptionRecord.objects.values(
        'product__name',
        'user__department'
    ).annotate(
        total_consumed=Sum('quantity')
    ).order_by('user__department', 'product__name')

    # تحويل الاختصارات إلى أسماء كاملة للقسم
    for item in department_consumption_data:
        for choice_value, choice_label in CustomUser.DEPARTMENT_CHOICES:
            if choice_value == item['user__department']:
                item['department_display'] = choice_label
                break
        else:
            item['department_display'] = "غير محدد"

    return render(request, 'inventory/limited_admin_dashboard.html', {
        'products': products,
        'low_stock_products_admin': low_stock_products,
        'orders': orders,
        'admin_monthly_consumption': department_consumption_data,
        'current_month': datetime.now().strftime('%B %Y')
    })


# ➕ إضافة منتج جديد (للمدير)
@login_required
@permission_required('inventory.can_manage_products', login_url='inventory:login') # يتطلب صلاحية إدارة المنتجات
def add_product(request):
    """يعالج إضافة منتج جديد."""
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'تمت إضافة المنتج بنجاح.')
            # إعادة التوجيه بناءً على نوع المدير
            if request.user.is_superuser or request.user.has_perm('inventory.can_approve_users'):
                return redirect('inventory:admin_dashboard')
            elif request.user.has_perm('inventory.can_manage_products') or request.user.has_perm('inventory.can_manage_orders'):
                return redirect('inventory:limited_admin_dashboard')
            else:
                return redirect('inventory:login') # fallback
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"خطأ في حقل {field}: {error}")
            messages.error(request, 'حدث خطأ أثناء إضافة المنتج. يرجى التحقق من البيانات المدخلة.')
    else:
        form = ProductForm()
    return render(request, 'add_product.html', {'form': form})

# ✏️ تعديل منتج موجود (للمدير)
@login_required
@permission_required('inventory.can_manage_products', login_url='inventory:login') # يتطلب صلاحية إدارة المنتجات
def edit_product(request, product_id):
    """يعالج تعديل منتج موجود."""
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            messages.success(request, 'تم تعديل المنتج بنجاح.')
            # إعادة التوجيه بناءً على نوع المدير
            if request.user.is_superuser or request.user.has_perm('inventory.can_approve_users'):
                return redirect('inventory:admin_dashboard')
            elif request.user.has_perm('inventory.can_manage_products') or request.user.has_perm('inventory.can_manage_orders'):
                return redirect('inventory:limited_admin_dashboard')
            else:
                return redirect('inventory:login') # fallback
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"خطأ في حقل {field}: {error}")
            messages.error(request, 'حدث خطأ أثناء تعديل المنتج. يرجى التحقق من البيانات المدخلة.')
    else:
        form = ProductForm(instance=product)
    return render(request, 'edit_product.html', {'form': form, 'product': product})

# 🗑️ حذف منتج (للمدير)
@login_required
@permission_required('inventory.can_manage_products', login_url='inventory:login') # يتطلب صلاحية إدارة المنتجات
def delete_product(request, product_id):
    """
    يعالج حذف منتج.
    يتوقع طلب POST من نافذة تأكيد منبثقة.
    """
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        product.delete()
        messages.success(request, f'تم حذف المنتج "{product.name}" بنجاح.')
        # إعادة التوجيه بناءً على نوع المدير
        if request.user.is_superuser or request.user.has_perm('inventory.can_approve_users'):
            return redirect('inventory:admin_dashboard')
        elif request.user.has_perm('inventory.can_manage_products') or request.user.has_perm('inventory.can_manage_orders'):
            return redirect('inventory:limited_admin_dashboard')
        else:
            return redirect('inventory:login') # fallback
    # إذا كان طلب GET، أعد التوجيه إلى لوحة تحكم المدير (لم نعد نستخدم صفحة تأكيد منفصلة)
    if request.user.is_superuser or request.user.has_perm('inventory.can_approve_users'):
        return redirect('inventory:admin_dashboard')
    elif request.user.has_perm('inventory.can_manage_products') or request.user.has_perm('inventory.can_manage_orders'):
        return redirect('inventory:limited_admin_dashboard')
    else:
        return redirect('inventory:login') # fallback

# ✅ موافقة المدير على طلب تسجيل مستخدم
@login_required
@permission_required('inventory.can_approve_users', login_url='inventory:login') # يتطلب صلاحية الموافقة على المستخدمين
def user_approve(request, user_id):
    """يوافق على طلب تسجيل مستخدم جديد."""
    user = get_object_or_404(CustomUser, id=user_id)
    user.is_approved = True
    user.is_active = True
    user.save()

    messages.success(request, f'تمت الموافقة على المستخدم {user.username}.')
    return redirect('inventory:admin_dashboard')

# ❌ رفض المدير لطلب تسجيل مستخدم
@login_required
@permission_required('inventory.can_approve_users', login_url='inventory:login') # يتطلب صلاحية الموافقة على المستخدمين
def user_reject(request, user_id):
    """يرفض طلب تسجيل مستخدم جديد ويحذف المستخدم."""
    user = get_object_or_404(CustomUser, id=user_id)
    username = user.username
    user_email = user.email
    user.delete()

    messages.info(request, f'تم رفض حساب المستخدم {username} وحذفه.')
    return redirect('inventory:admin_dashboard')

# ✅ موافقة المدير على الطلب
@login_required
@permission_required('inventory.can_manage_orders', login_url='inventory:login') # يتطلب صلاحية إدارة الطلبات
def approve_order(request, order_id):
    """يوافق على طلب منتج."""
    order = get_object_or_404(Order, id=order_id)
    if order.status == 'Pending':
        if order.quantity > order.product.quantity:
            messages.error(request, f'لا يمكن الموافقة على الطلب #{order.id} لمنتج {order.product.name} لأن الكمية المطلوبة ({order.quantity}) أكبر من المتاح ({order.product.quantity}).')
            # إعادة التوجيه بناءً على نوع المدير
            if request.user.is_superuser or request.user.has_perm('inventory.can_approve_users'):
                return redirect('inventory:admin_dashboard')
            elif request.user.has_perm('inventory.can_manage_products') or request.user.has_perm('inventory.can_manage_orders'):
                return redirect('inventory:limited_admin_dashboard')
            else:
                return redirect('inventory:login') # fallback

        order.status = 'Approved'
        order.approved_at = datetime.now()
        order.product.quantity -= order.quantity
        order.product.save()
        order.save()

        current_month = datetime.now().strftime('%Y-%m')
        report_entry, created = Report.objects.get_or_create(
            user=order.user,
            month=current_month,
            product=order.product,
            defaults={'consumed': order.quantity, 'remaining': order.product.quantity}
        )
        if not created:
            report_entry.consumed += order.quantity
            report_entry.remaining = order.product.quantity
            report_entry.save()

        ConsumptionRecord.objects.create(
            user=order.user,
            product=order.product,
            quantity=order.quantity
        )

        messages.success(request, f'تمت الموافقة على الطلب #{order.id}.')
    else:
        messages.warning(request, f'لا يمكن الموافقة على الطلب #{order.id} لأنه ليس في حالة "معلق".')
    
    # إعادة التوجيه بناءً على نوع المدير
    if request.user.is_superuser or request.user.has_perm('inventory.can_approve_users'):
        return redirect('inventory:admin_dashboard')
    elif request.user.has_perm('inventory.can_manage_products') or request.user.has_perm('inventory.can_manage_orders'):
        return redirect('inventory:limited_admin_dashboard')
    else:
        return redirect('inventory:login') # fallback

# ❌ رفض المدير للطلب
@login_required
@permission_required('inventory.can_manage_orders', login_url='inventory:login') # يتطلب صلاحية إدارة الطلبات
def reject_order(request, order_id):
    """يرفض طلب منتج."""
    order = get_object_or_404(Order, id=order_id)
    if order.status == 'Pending':
        order.status = 'Rejected'
        order.save()

        messages.info(request, f'تم رفض الطلب #{order.id}.')
    else:
        messages.warning(request, f'لا يمكن رفض الطلب #{order.id} لأنه ليس في حالة "معلق".')
    
    # إعادة التوجيه بناءً على نوع المدير
    if request.user.is_superuser or request.user.has_perm('inventory.can_approve_users'):
        return redirect('inventory:admin_dashboard')
    elif request.user.has_perm('inventory.can_manage_products') or request.user.has_perm('inventory.can_manage_orders'):
        return redirect('inventory:limited_admin_dashboard')
    else:
        return redirect('inventory:login') # fallback

# 🛒 تقديم طلب جديد (صفحة منفصلة لطلب منتج واحد)
@login_required
@user_passes_test(lambda u: u.is_approved if not u.is_admin else True, login_url='inventory:login')
def place_order(request, product_id):
    """
    يعالج طلب المستخدم لمنتج واحد من صفحة المنتجات.
    """
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        try:
            qty = int(request.POST['quantity'])
            if qty > 0 and qty <= product.quantity:
                cart_item, created = Cart.objects.get_or_create(
                    user=request.user, 
                    product=product,
                    defaults={'quantity': qty}
                )
                if not created:
                    cart_item.quantity += qty
                    cart_item.save()
                messages.success(request, 'تمت إضافة المنتج إلى السلة.')
                return redirect('inventory:user_dashboard')
            else:
                messages.error(request, 'الكمية المطلوبة غير صالحة أو أكبر من المتاح.')
        except ValueError:
            messages.error(request, 'الكمية يجب أن تكون رقمًا صحيحًا.')
    return render(request, 'place_order.html', {'product': product})


# 👤 صفحة الملف الشخصي للمستخدم العادي
@login_required
@user_passes_test(lambda u: u.is_approved if not u.is_admin else True, login_url='inventory:login')
def user_profile_view(request):
    """
    يعرض تفاصيل الملف الشخصي للمستخدم العادي ويتيح تغيير كلمة المرور.
    """
    if request.method == 'POST':
        # معالجة تغيير كلمة المرور
        password_form = PasswordChangeForm(request.user, request.POST)
        if password_form.is_valid():
            user = password_form.save()
            update_session_auth_hash(request, user) # هام لتحديث الجلسة بعد تغيير كلمة المرور
            messages.success(request, 'تم تغيير كلمة المرور بنجاح!')
            return redirect('inventory:user_profile_view') # إعادة التوجيه لتحديث الصفحة
        else:
            messages.error(request, 'الرجاء تصحيح الأخطاء أدناه.')
    else:
        password_form = PasswordChangeForm(request.user)

    context = {
        'user_obj': request.user,
        'password_form': password_form,
    }
    return render(request, 'user_profile.html', context)

# 👤 دالة حذف الحساب
@login_required
@user_passes_test(lambda u: not u.is_admin, login_url='inventory:login') # فقط المستخدمون غير المديرين يمكنهم حذف حساباتهم
def delete_account(request):
    """
    يعالج حذف حساب المستخدم بعد تأكيد كلمة المرور.
    """
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            # تحقق من أن كلمة المرور المدخلة صحيحة للمستخدم الحالي
            user = authenticate(request, username=request.user.username, password=form.cleaned_data['password'])
            if user is not None and user == request.user:
                username = request.user.username
                request.user.delete()
                logout(request) # تسجيل الخروج بعد حذف الحساب
                messages.success(request, f'تم حذف حسابك {username} بنجاح.')
                return redirect('inventory:login')
            else:
                messages.error(request, 'كلمة المرور غير صحيحة.')
        else:
            messages.error(request, 'الرجاء إدخال كلمة المرور لتأكيد الحذف.')
    return redirect('inventory:user_profile_view') # إعادة التوجيه إلى صفحة الملف الشخصي إذا لم يكن طلب POST صحيحًا
    

# 👤 صفحة الملف الشخصي للمدير
@login_required
@user_passes_test(is_admin, login_url='inventory:login')
def admin_profile_view(request):
    """يعرض تفاصيل الملف الشخصي للمدير."""
    context = {
        'user_obj': request.user,
    }
    return render(request, 'admin_profile.html', context)
