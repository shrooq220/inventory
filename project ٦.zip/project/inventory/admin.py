# inventory/admin.py
from django.contrib import admin
from .models import CustomUser, Product, Cart, Order, Report, ConsumptionRecord

# تسجيل نموذج المستخدم المخصص
@admin.register(CustomUser)
class CustomUserAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'is_admin', 'is_approved', 'department') # إضافة department
    list_filter = ('is_admin', 'is_approved', 'department') # إضافة department
    search_fields = ('username', 'email')
    actions = ['approve_users', 'reject_users']

    def approve_users(self, request, queryset):
        queryset.update(is_approved=True, is_active=True)
        self.message_user(request, "تمت الموافقة على المستخدمين المحددين بنجاح.")
    approve_users.short_description = "الموافقة على المستخدمين المحددين"

    def reject_users(self, request, queryset):
        queryset.update(is_approved=False, is_active=False) # أو queryset.delete() لحذفهم
        self.message_user(request, "تم رفض المستخدمين المحددين.")
    reject_users.short_description = "رفض المستخدمين المحددين"

# تسجيل نموذج المنتج
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'quantity', 'category', 'created_at', 'updated_at')
    list_filter = ('category',)
    search_fields = ('name', 'description')

# تسجيل نموذج سلة التسوق
@admin.register(Cart)
class CartAdmin(admin.ModelAdmin):
    list_display = ('user', 'product', 'quantity', 'added_at') # تم التحديث: created_at إلى added_at
    list_filter = ('user', 'product', 'added_at') # تم التحديث: created_at إلى added_at
    search_fields = ('user__username', 'product__name')

# تسجيل نموذج الطلب
@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ('user', 'product', 'quantity', 'status', 'created_at', 'approved_at')
    list_filter = ('status', 'created_at', 'user', 'product')
    search_fields = ('user__username', 'product__name')
    actions = ['approve_orders', 'reject_orders']

    def approve_orders(self, request, queryset):
        for order in queryset:
            if order.status == 'Pending':
                order.status = 'Approved'
                order.product.quantity -= order.quantity
                order.product.save()
                order.save()
        self.message_user(request, "تمت الموافقة على الطلبات المحددة.")
    approve_orders.short_description = "الموافقة على الطلبات المحددة"

    def reject_orders(self, request, queryset):
        queryset.update(status='Rejected')
        self.message_user(request, "تم رفض الطلبات المحددة.")
    reject_orders.short_description = "رفض الطلبات المحددة"

# تسجيل نموذج سجل الاستهلاك
@admin.register(ConsumptionRecord)
class ConsumptionRecordAdmin(admin.ModelAdmin):
    list_display = ('user', 'product', 'quantity', 'consumed_at')
    list_filter = ('user', 'product', 'consumed_at')
    search_fields = ('user__username', 'product__name')

# تسجيل نموذج التقرير
@admin.register(Report)
class ReportAdmin(admin.ModelAdmin):
    list_display = ('user', 'product', 'month', 'consumed', 'remaining', 'created_at')
    list_filter = ('user', 'month', 'product')
    search_fields = ('user__username', 'product__name', 'month')